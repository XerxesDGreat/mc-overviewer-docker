                                      =-= Silver Default =-=

The goal of this resource pack is to simply take vanilla textures, and make them have a higher resolution.
It's similar to the Faithful resource pack, but it adds many more features. The pack will be updated
as more items, blocks, mobs, etc are added (this includes snapshot features). Updates will be posted on
the forum post. Enjoy :D


Resource Pack Creator (IGN): Silver_David
	Twitter:             @SilverDavid_MC
	Minecraft Forums:    SilverDavid